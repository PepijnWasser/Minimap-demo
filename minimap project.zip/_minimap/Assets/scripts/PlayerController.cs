using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float movementSpeed;

    void Update()
    {
        float deltaX = 0;
        float deltaY = 0;

        if (Input.GetKey(KeyCode.D))
        {
            deltaX = 1;
        }
        if (Input.GetKey(KeyCode.A))
        {
            deltaX = -1;
        }
        if (Input.GetKey(KeyCode.W))
        {
            deltaY = 1;
        }
        if (Input.GetKey(KeyCode.S))
        {
            deltaY = -1;
        }

        SpriteRenderer renderer = GetComponent<SpriteRenderer>();
        if (deltaX > 0)
        {
            renderer.flipX = false;
        }
        else if (deltaX < 0)
        {
            renderer.flipX = true;
        }

        transform.Translate(new Vector3(deltaX, deltaY, 0) * movementSpeed * Time.deltaTime);
    }
}
