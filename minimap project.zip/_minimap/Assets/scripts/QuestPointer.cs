using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestPointer : MonoBehaviour
{
    public GameObject target;
    Vector3 targetPosition;
    public GameObject pointerRectTransform;

    // Update is called once per frame
    void Update()
    {
        targetPosition = target.transform.position;
        Vector3 toPosition = targetPosition;
        Vector3 fromPosition = Camera.main.transform.position;
        fromPosition.z = 0;
        Vector3 dir = (toPosition - fromPosition).normalized;
        Debug.Log(dir.x);

        pointerRectTransform.transform.right = dir;
    }
}
