using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StickToObject : MonoBehaviour
{
    public GameObject target;

    void Update()
    {
        if(target != null)
        {
            this.transform.position = new Vector3(target.transform.position.x, target.transform.position.y, transform.position.z);
        }  
    }
}
